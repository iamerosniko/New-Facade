Created By   : Eros Niko Cas Alvarez
Job Title    : Software Developer
Date Started : 07 / 29 / 2016  
------------------------------------------------------------------------------------------------------------------
"I cannot create this Framework without the help of my master mentor Sir Federico Paras Sarmiento and ma'am joyce bermoy."
------------------------------------------------------------------------------------------------------------------

This file is the Version information of Facade Framework

version 1.0.0.0
	*the beta test of FF

version 1.0.0.1
	*the full template of FF

version 1.0.0.2
	*modification of DL_DA_GENERIC 	

version 1.0.0.3
	*obsoletion of some methods in DL_UT_ACCESSDB
	*getData in DL_UT_ACCESSDB now returns a recordset
	*getData in DL_DA_GENERIC now returns a recordset
	*fixed BL_BC_ICRUD interfaces
	  1. BL_BC_ICRUD_WhereSets accepts string as mode (SELECT, UPDATE, EDIT)
	*TEMPLATE_BW
	  1. BL_BC_ICRUD_WhereSets needs to pass a string ("SELECT, UPDATE, DELETE")

version 1.0.0.4
	*added form templates (Buttons and textboxes with different approach
	*fix minor bugs

version 1.0.1.0
	*added Advanced Search for msaccess database.

version 1.0.1.1 to 1.0.1.5 
	*advanced search functionality is currently working
	*fix some bugs

version 1.0.1.6
	*simplified coding advanced search
	*can now export data to excel
	*fix minor bugs


==================================================================================================================
Expectations on next improvement

1. with GUI components templates
2. string maniputation
3. stock validation
4. connection repository --- ideal: either file handling / the directory source is saved from access database
5. application facade class
6. service layer class


	